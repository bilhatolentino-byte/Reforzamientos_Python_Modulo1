"""
5. Ingresar el nombre de tu carrera dentro de los valores que tienes en tu
diccionario.
- Mostrar en consola los valores de tu carrera y nombre agregándolos a
una variable c/u
"""
persona = { "nombre": "Bilha", "edad": 19, "salario": 2500}


persona["carrera"] = "Ingeniería Industrial"



print("Nombre:", persona["nombre"])
print("Carrera:", persona["carrera"])

